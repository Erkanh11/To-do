import "./App.css";

import { useState } from "react";

import Header from "./components/Header";
import TodoForm from "./components/TodoForm";
import SearchBar from "./components/SearchBar";
import FilterButtons from "./components/FilterButtons";
import TodoList from "./components/TodoList";

function App() {
  const [tasks, setTasks] = useState([]);

  return (
    <div className="container">
      <Header />
      <TodoForm />
      <SearchBar />
      <FilterButtons />
      <TodoList tasks={tasks} />
    </div>
  );
}

export default App;
