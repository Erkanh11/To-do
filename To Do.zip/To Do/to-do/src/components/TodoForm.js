import React, { useState } from 'react';

function TodoForm() {
  const [text, setText] = useState("");

  return (
    <>
    
    <input type="text" 
    placeholder="Add a new task..."
    value={text}
    onChange={(e) => setText(e.target.value)}
     />
    <button type="submit">Add</button>
    </>
  );
}

export default TodoForm;